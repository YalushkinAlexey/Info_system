
def log():
    pass