
#ToDo придумать красивый выход
def menu():
    print(f'1 - write csv,  2 - read & print csv, 3 - edit note, 4 - change salary 0 - exit')
    z = input(' ? - ')
    match z :
        case '1' : pass
        case '2' : pass
        case '3' : pass
        case '4' : pass
        case '0' : pass

    pass

#расписать - меню  1 вывести список
#2 ввести работника
#3 установить зп
#4 изменить разряд
#5 выдать премию
#6 уволить работника
