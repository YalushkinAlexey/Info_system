
#редактирование по работнику
def edit_note():
    pass

#это при вводе нового сотрудника
def set_surname():
    surname = input('введите фамилию: ')
    return surname

def set_name():
    name =input('введите имя :')
    return name

def set_born_date():
    born_date =input('число, месяц, год рождения :')
    return born_date

def set_job_title():
    job_title = input('должность сотрудника: ')
    return job_title

def set_rank():
    rank = input('введите разряд: ')
    return rank

def set_salary():
    salary = input('введите зарплату по договору найма ')
    return salary

#эта ф-ия собирает с предидущих функций значения и передает для записи в базу
def set_employee():
    pass
#ф-ии которые надо продумать::: ToDo
def salary_edit():
    pass

def rank_edit():
    pass

def award_edit():
    pass



