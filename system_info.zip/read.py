

def read_file():
    #спилить с прошлого проекта
    pass
