# This is a sample Python script.

#employee - работник

#worker - рабочий
#booker - бухгалтер
#foreman - мастер
#director

#chief - начальник
#job_title - должность
#salary - зарплата
#rank - разряд
#tax - коэф от разряда
#award - премия

