

def write_file():
    #спилить с прошлого проекта
    pass

